TotK DynamicFPS 1.5.5beta3 by /u/ChucksFeedAndSeed
Check https://www.reddit.com/user/ChucksFeedAndSeed/ for updates.

To enable DynamicFPS ensure the "DynamicFPS - #1-0 - v1.5.5 (Required)" mod folder is enabled in your emulator.
With that enabled you can then enable the extra mods marked (Optional) to configure it as you like.

---

If you'd like to support my work I have a ko-fi page at https://ko-fi.com/ChucksFeedAndSeed :)
