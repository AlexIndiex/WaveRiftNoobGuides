Optional extra to make DynamicFPS change the framerate limit for you.
Make sure to also enable the main DynamicFPS mod marked (Main) for this to be active.